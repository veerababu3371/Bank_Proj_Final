package com.cg.ars.dto;

public class Users {

	public Users(String username, String password, String role, String mno) {
		super();
		this.username = username;
		this.password = password;
		this.role = role;
		this.mno = mno;
	}
	private String username;
	private String password;
	private String role;
	private String mno;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getpassword() {
		return password;
		
	}
	public void setpassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getMno() {
		return mno;
	}
	public void setMno(String mno) {
		this.mno = mno;
	}
	@Override
	public String toString() {
		return "Users [username=" + username + ", password=" + password + ", role="
				+ role + ", mno=" + mno + "]";
	}
	
}
