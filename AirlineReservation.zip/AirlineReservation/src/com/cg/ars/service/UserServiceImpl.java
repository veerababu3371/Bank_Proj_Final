package com.cg.ars.service;


import com.cg.ars.dao.UserDao;
import com.cg.ars.dao.UserDaoImpl;
import com.cg.ars.dto.Users;
import com.cg.ars.exception.FlightException;

public class UserServiceImpl implements UserService{
	
	UserDao dao;
	public void setDao(UserDao dao){
		this.dao = dao;
	}
	
	public UserServiceImpl()
	{
		dao = new UserDaoImpl();
	}

	@Override
	public Users checkLogin(String username, String password)
			throws FlightException {
				return dao.checkLogin(username, password);
				
		// TODO Auto-generated method stub
		
	}

	

}
