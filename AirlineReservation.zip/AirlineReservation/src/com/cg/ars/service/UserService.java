package com.cg.ars.service;

import com.cg.ars.dto.Users;
import com.cg.ars.exception.FlightException;

public interface UserService {

	public Users checkLogin(String username, String password) throws FlightException;
}
