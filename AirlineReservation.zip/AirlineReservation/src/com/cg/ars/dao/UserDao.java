package com.cg.ars.dao;

import com.cg.ars.dto.Users;
import com.cg.ars.exception.FlightException;

public interface UserDao {

	public Users checkLogin(String username, String password) throws FlightException;
	
	//public boolean testLogin(boolean var1);
}
