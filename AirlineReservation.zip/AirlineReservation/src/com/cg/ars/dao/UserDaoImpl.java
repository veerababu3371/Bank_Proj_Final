package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.ars.dto.Users;
import com.cg.ars.exception.FlightException;
import com.cg.ars.util.DBUtil;
import com.cg.logger.MyLogger;

public class UserDaoImpl implements UserDao {

	Connection con;
	Logger logger;

	public UserDaoImpl() {
		con = DBUtil.getConnect();
		logger = MyLogger.getLogger();
	}

	@Override
	public Users checkLogin(String username, String password) {
		Users user = null;
		String qry = "SELECT username, password FROM USERS";

		try {

			PreparedStatement pstmt = con.prepareStatement(qry);
			ResultSet rs = pstmt.executeQuery(qry);

			while (rs.next()) {
				String uname = rs.getString("username");
				String pass = rs.getString("password");

				if ((username.equals(uname)) && (password.equals(pass))) {

					System.out.println("User verified");
					
					

				} else {

					System.out.println("Please Check Username and Password ");
					break;

				}
				//rs.next();
				
			}
		} catch (SQLException e) {

			System.out.println(e);
		}
		return user;

	}
	
	

	
}
